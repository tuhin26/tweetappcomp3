﻿using Microsoft.Azure.NotificationHubs;

namespace App.Tweet.DAL
{
    public class Notifications
    {
        public static Notifications Instance = new Notifications();

        public NotificationHubClient Hub { get; set; }

        private Notifications()
        {
            Hub = NotificationHubClient.CreateClientFromConnectionString("Endpoint=sb://mynotifier.servicebus.windows.net/;SharedAccessKeyName=DefaultFullSharedAccessSignature;SharedAccessKey=OiNoC8rfslH79bqlG2TcDE1wp4QF6bH8eLmG3Qepmdo=",
                                                                            "mynotifierhub");
        }
    }
}
