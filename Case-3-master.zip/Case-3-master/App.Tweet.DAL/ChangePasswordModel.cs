﻿using System;
using System.Collections.Generic;
using System.Text;

namespace App.Tweet.DAL
{
   public class ChangePasswordModel
    {
        public string password { get; set; }
        public string newPassword { get; set; }
    }
}
