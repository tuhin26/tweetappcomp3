﻿using App.Tweet.DAL;
using App.Tweet.ForgetPasswordService.Interface;
using App.Tweet.Service.Interface;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.WebUtilities;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using Microsoft.Azure.NotificationHubs;
using Microsoft.Azure.NotificationHubs.Messaging;
using System.Threading.Tasks;
using System.Web;
using Microsoft.Extensions.Caching.Distributed;
using Newtonsoft.Json;

namespace App.TweetWebApi.Controllers
{
    [Route("api/v1.0/tweets/")]
    [AllowAnonymous]
    public class UserController : Controller
    {
        private readonly IUserService _userService;
        private readonly IConfiguration _config;
        private readonly ISender _emailSender;
        private NotificationHubClient hub;
        IDistributedCache _distributedCache;

        public UserController(IUserService userService, IConfiguration configuration, ISender sender,IDistributedCache distributedCache)
        {
            _userService = userService;
            _config = configuration;
            _emailSender = sender;
            hub = Notifications.Instance.Hub;
            _distributedCache = distributedCache;
        }

      
        [HttpPost]
        [Route("Register")]
        [AllowAnonymous]
        public JsonResult Register([FromBody] UserModel user)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    string token = GenerateJWT();
                    user.token = token;
                    bool creationStatus = _userService.Register(user);
                    if (creationStatus)
                    {
                        return new JsonResult("User registered successfully");
                    }
                    return new JsonResult("User already exists");
                }
                else
                {
                    return new JsonResult("Please enter all the valid inputs");
                }

            }
            catch (Exception ex)
            {
                string message = "Meesage : " + ex.Message + " & Stacktrace: " + ex.StackTrace;
            }
            return new JsonResult("Error");
        }

       
        [HttpPost]
        [AllowAnonymous]
        [Route("Login")]
        public JsonResult Login([FromBody] LoginModel user)
        {
            IActionResult response = Unauthorized();
            UserModel userInfo = new UserModel();
            try
            {
                if (ModelState.IsValid)
                {
                    var userExist = _userService.Login(user);
                    if (userExist == null)
                    {
                        return new JsonResult("User not found");
                    }
                    else if (userExist != null && (userExist.password == user.password))
                    {
                        var tokenString = GenerateJSONWebToken(user.email);
                        userExist.token = tokenString;
                        return new JsonResult(userExist);
                    }
                    else
                    {
                        return new JsonResult("Username or Password is incorrect");
                    }
                }
                else
                {
                    return new JsonResult("Enter all the valid required fields");
                }


            }
            catch (Exception ex)
            {
                string message = "Meesage : " + ex.Message + " & Stacktrace: " + ex.StackTrace;
            }
            return new JsonResult("Error");
        }

       
        [HttpPut]
        [Route("ChangePassword/{loginId}")]
        public JsonResult ChangePassword(string loginId, [FromBody] ChangePasswordModel changePassword)
        {
            try
            {
                bool valid = _userService.ChangePassword(loginId, changePassword);
                if (valid)
                {
                    return new JsonResult("Password changed successfully");
                }
                return new JsonResult("Old password is incorrect");
            }
            catch (Exception ex)
            {
                string message = "Meesage : " + ex.Message + " & Stacktrace: " + ex.StackTrace;
            }
            return new JsonResult("Error");
        }

        private string GenerateJWT()
        {
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_config["Jwt:Key"]));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
              _config["Jwt:Issuer"],
              _config["Jwt:Issuer"],
              null,
              expires: DateTime.Now.AddMinutes(120),
              signingCredentials: credentials);

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        private string GenerateJSONWebToken(string email)
        {
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_config["Jwt:Key"]));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

            var claims = new[] {
                    new Claim(JwtRegisteredClaimNames.Email, email)
            };

            var token = new JwtSecurityToken(_config["Jwt:Issuer"],
                _config["Jwt:Issuer"],
                claims,
                expires: DateTime.Now.AddMinutes(120),
                signingCredentials: credentials);

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        [HttpPost]
        [AllowAnonymous]
        [Route("ForgotPassword")]
        public IActionResult ForgotPassword([FromBody] ForgotPasswordModel forgotPassword)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return new JsonResult("Invalid Request");
                }

                var user = _userService.CheckUserExists(forgotPassword.Email);

                if (user != null)
                {
                    var token = GenerateJSONWebToken(forgotPassword.Email);

                    var isTokenGenerater = _userService.SaveToken(user.email, token);
                    if (isTokenGenerater != false)
                    {

                        var param = new Dictionary<string, string>
                        {
                            {"token", token },
                            {"email", forgotPassword.Email }
                        };

                        var callback = QueryHelpers.AddQueryString(forgotPassword.ClientURI, param);

                        var message = new EmailMessage(new string[] { forgotPassword.Email }, "Reset password token", callback);

                        _emailSender.SendEmail(message);

                        return new JsonResult("Mail Sent");
                    }

                }
            }
            catch (Exception ex)
            {
                string message = "Meesage : " + ex.Message + " & Stacktrace: " + ex.StackTrace;
            }

            return new JsonResult("Invalid Request");
        }


        [HttpPut]
        [Route("ResetPassword")]

        [AllowAnonymous]
        public JsonResult ResetPassword([FromBody] ResetPasswordModel resetPassword)
        {
            try
            {

                if (!ModelState.IsValid)
                {
                    return new JsonResult("Invalid Request");
                }

                var user = _userService.CheckUserExists(resetPassword.email);
                if (user != null)
                {
                    if (user.token == resetPassword.token)
                    {
                        bool valid = _userService.ResetPassword(resetPassword);

                        if (valid)
                        {
                            return new JsonResult("Password changed successfully");
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                string message = "Meesage : " + ex.Message + " & Stacktrace: " + ex.StackTrace;
            }

            return new JsonResult("Invalid Request");
        }

        [HttpGet]
        [Route("GetUserById/{id}")]
        public JsonResult GetUserById(string id)
        {
            UserModel userById = new UserModel();
            try
            {
                var cachedObj = _distributedCache.GetString("GetUserById");
                if (string.IsNullOrEmpty(cachedObj))
                {
                    userById = _userService.GetUserById(id);
                    if (userById != null)
                    {
                        _distributedCache.SetString("GetUserById", JsonConvert.SerializeObject(userById));
                        return new JsonResult(userById);
                    }
                    return new JsonResult("User not found");
                }
                else
                {
                    userById = JsonConvert.DeserializeObject<UserModel>(cachedObj);
                    return new JsonResult(userById);
                }
            }
            catch (Exception ex)
            {
                string message = "Meesage : " + ex.Message + " & Stacktrace: " + ex.StackTrace;
            }
            return new JsonResult("Error");
        }

        [HttpGet]
        [Route("GetUserByUsername/{username}")]
        public JsonResult GetUserByUsername(string username)
        {
            UserModel userByUserName = new UserModel();
            try
            {
                var cachedObj = _distributedCache.GetString("GetUserByUsername");
                if (string.IsNullOrEmpty(cachedObj))
                {
                    userByUserName = _userService.GetUserByUsername(username);
                    if (userByUserName != null)
                    {
                        _distributedCache.SetString("GetUserByUsername", JsonConvert.SerializeObject(userByUserName));
                        return new JsonResult(userByUserName);
                    }
                    return new JsonResult("User not found");
                }
                else
                {
                    userByUserName = JsonConvert.DeserializeObject<UserModel>(cachedObj);
                    return new JsonResult(userByUserName);
                }

            }
            catch (Exception ex)
            {
                string message = "Meesage : " + ex.Message + " & Stacktrace: " + ex.StackTrace;
            }
            return new JsonResult("Error");
        }


        [HttpGet]
        [Route("users/all")]
        public JsonResult GetAllUsers()
        {
            List<UserModel> allUsers = new List<UserModel>();
            try
            {
                var cachedObj = _distributedCache.GetString("GetAllUsers");
                if (string.IsNullOrEmpty(cachedObj))
                {
                    allUsers = _userService.GetAllUsers().ToList();
                    if (allUsers != null)
                    {
                        _distributedCache.SetString("GetAllUsers", JsonConvert.SerializeObject(allUsers));
                        return new JsonResult(allUsers);
                    }
                    return new JsonResult("Users not found");
                }
                else
                {
                    allUsers = JsonConvert.DeserializeObject<List<UserModel>>(cachedObj);
                    return new JsonResult(allUsers);
                }
            }
            catch (Exception ex)
            {
                string message = "Meesage : " + ex.Message + " & Stacktrace: " + ex.StackTrace;
            }
            return new JsonResult("Error");
        }


    }
}
