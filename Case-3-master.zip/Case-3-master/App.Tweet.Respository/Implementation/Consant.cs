﻿using System;
using System.Collections.Generic;
using System.Text;

namespace App.Tweet.Respository.Implementation
{
    public static class Consant
    {
        public static string connectionString = "mongodb://apptweetwebapiaccount:7VzDi5tbAzXQ2jV2ZisT2Juh1RGiwAGFUu63vxFCZxMX52fLue4vNyUjguqTC7U0xjvqJbKskCBRyphmZS4ECQ==@apptweetwebapiaccount.mongo.cosmos.azure.com:10255/?ssl=true&retrywrites=false&replicaSet=globaldb&maxIdleTimeMS=120000&appName=@apptweetwebapiaccount@";
        public static string dataBaseName = "TweetAppDB";

       // public static string connectionString = "mongodb://tweet-database:eHDxHWr0BhppxbLrQra2X6ZpDatbTH2llDm1Mgw5n86nEjO9xQkJEE6wS0reIo1P8qGUf9yXg4IgjSkN6qrOlg==@tweet-database.mongo.cosmos.azure.com:10255/?ssl=true&replicaSet=globaldb&retrywrites=false&maxIdleTimeMS=120000&appName=@tweet-database@";
       

    }
}
