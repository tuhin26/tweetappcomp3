﻿using App.Tweet.DAL;
using App.Tweet.Respository.Interface;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;

namespace App.Tweet.Respository.Implementation
{
    public class TweetCommentsRepository : ITweetCommentsRepository
    {
        private readonly IMongoCollection<TweetCommentsModel> _tweetCommentsData;

        public TweetCommentsRepository(IDatabaseSettings databaseSettings)
        {
            var client = new MongoClient(Consant.connectionString);
            var database = client.GetDatabase(Consant.dataBaseName);
            _tweetCommentsData = database.GetCollection<TweetCommentsModel>("ReplyData");
        }

        public List<TweetCommentsModel> FindAll()
        {
            return _tweetCommentsData.Find(CommentModel => true).ToList(); ;
        }

        public List<TweetCommentsModel> FindAllByCondition(string tweetId)
        {
            return _tweetCommentsData.Find(x => x.tweetId.Equals(tweetId)).ToList();
        }

        public TweetCommentsModel FindByCondition(Expression<Func<TweetCommentsModel, bool>> expression)
        {
            return _tweetCommentsData.Find(expression => true).FirstOrDefault();
        }

        public bool Create(TweetCommentsModel tweetComment)
        {
            bool isCreated = false;
            try
            {
                _tweetCommentsData.InsertOne(tweetComment);
                isCreated = true;
            }
            catch (Exception)
            {
                throw;
            }
            return isCreated;
        }

        public bool Update(TweetCommentsModel tweetComment)
        {
            bool isUpdated = false;
            try
            {
                _tweetCommentsData.ReplaceOne(x => x.commentId.Equals(tweetComment.commentId), tweetComment);
                isUpdated = true;
            }
            catch (Exception)
            {
                throw;
            }
            return isUpdated;
        }

        public bool Delete(string tweetCommentId)
        {
            bool isDeleted = false;
            try
            {
                _tweetCommentsData.DeleteOne(x => x.commentId.Equals(tweetCommentId));
                isDeleted = true;
            }
            catch (Exception)
            {
                throw;
            }
            return isDeleted;
        }

    }
}
