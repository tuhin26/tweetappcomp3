﻿using App.Tweet.DAL;
using System;
using System.Collections.Generic;
using System.Text;

namespace App.Tweet.Service.Interface
{
    public interface IUserService
    {

        UserModel CheckUserExists(string username);
        bool Register(UserModel userModel);
        UserModel Login(LoginModel user);
        bool SaveToken(string email, string token);
        bool ChangePassword(string loginId, ChangePasswordModel changePassword);
        bool ResetPassword(ResetPasswordModel resetPassword);
        List<UserModel> GetAllUsers();
        UserModel GetUserById(string userId);
        UserModel GetUserByUsername(string username);

    }
}
