﻿using MimeKit;
using App.Tweet.DAL;

namespace App.Tweet.ForgetPasswordService.Interface
{
   public interface ISender
    {
        void SendEmail(EmailMessage message);
        MimeMessage CreateEmailMessage(EmailMessage message);
        void Send(MimeMessage mailMessage);
    }
}
