import { Component, OnInit } from '@angular/core';
import { AuthorizedService } from 'src/app/shared/Services/Authorized/authorized.service';
import { FormBuilder,  Validators, FormGroup, FormControl, ReactiveFormsModule } from '@angular/forms';
import { UserComponent } from '../../user-search/user/user.component';
import {ActivatedRoute, Params, Router} from '@angular/router';

@Component({
  selector: 'app-edittweets',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {

  UpdateTweet: FormGroup;
  userId : number;
  submitted = false;
  
  user : any;
  first_name : string;
  last_name : string;
  fullName : string;
  routeurl:string;
  tweetId: any;
  Tweet : any;

  constructor(private authorizedService:AuthorizedService, private fb : FormBuilder,private route : ActivatedRoute,private router:Router) { }

  
  ngOnInit(): void {
    this.route.params
      .subscribe(
        (params: Params) => {
          this.tweetId = params['tweetId'];
          this.getTweetById(this.tweetId);
        }
    );
    this.UpdateTweet = this.fb.group({
      tweetDescription: ["", [Validators.required, Validators.maxLength(144)]]
    });

   

  }
  private getTweetById(tweetId : string)
  {
    const userId = localStorage.getItem("userId")!;
    this.authorizedService.getTweetById(tweetId, userId ).subscribe(data=>
    {
        this.Tweet = data;  
        console.log(this.Tweet);
        this.authorizedService.getUserById(this.Tweet.userId).subscribe(data=>
        {
            this.user = data;
            this.first_name = this.user.first_name;
            this.last_name = this.user.last_name;
        });                                                                                                                                                                                                                                                        
    });
  }

  OnSubmit()
  {
      this.submitted = true;
      if (this.UpdateTweet.invalid) {
          return;
      }

      const userId = localStorage.getItem("userId") == null ? "" : localStorage.getItem("userId");
      const username = localStorage.getItem("loginId") == null ? "" : localStorage.getItem("loginId");
 
      const tweet = 
      {
          userId : userId,
          tweetId:this.Tweet.tweetId,
          tweetDescription : this.UpdateTweet.value.tweetDescription,
          username : username
      }
     
      this.authorizedService.updateTweet(tweet)
      .subscribe(data =>
      {
          if(data == "Tweet updated")
          {
            console.log(data)

            this.router.navigate(['user-dashboard/my-tweets']);
          }
          else{
   
            console.log("error");
          }
      });


  }
}
