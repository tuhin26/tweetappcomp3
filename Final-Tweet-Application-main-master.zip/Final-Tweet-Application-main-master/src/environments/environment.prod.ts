export const environment = {
  production: true,
  url:"http://tweet.centralus.azurecontainer.io/api/v1.0/tweets"
};
